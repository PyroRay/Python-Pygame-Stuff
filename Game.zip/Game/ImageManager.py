#Image Manager for 3xCSL
#Python 2.7.18
#Harper Kim

import pygame

game_images = {"title": pygame.image.load("Title.png")}
character_images = None
effect_images = None

image_list = {"game": game_images, "character": character_images, "effect": effect_images}